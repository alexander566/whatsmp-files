This map was created way back in 2022!
You can use it on your server, but using it for commercial purposes is strictly prohibited!
If you liked the map, please give it a like on the site where you downloaded it! Good luck! :)

Our discord: https://discord.gg/V7JsvBzntU