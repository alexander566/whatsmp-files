#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;
in float vIsGui;

// --- OmForge MagicShaders item effects (/omf effect) ---
flat in vec4 rawColor;
in vec3 msViewNormal;
in vec3 msViewPos;

out vec4 fragColor;

// ===== MagicShaders helpers (ported from the dead rendertype_item_entity_translucent_cull) =====
int msHash(int x) { x += (x << 10); x ^= (x >> 6); x += (x << 3); x ^= (x >> 11); x += (x << 15); return x; }
int msNoise(ivec2 v, int seed) { return msHash(v.x ^ msHash(v.y + seed) ^ msHash(seed)); }
float msLum(vec4 col) { return col.r * 0.299 + col.g * 0.587 + col.b * 0.114; }
vec3 msHue(float h) { return clamp(abs(mod(h * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0); }
float msVnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    float a = float(abs(msNoise(ivec2(i), 0)) % 1000) / 1000.0;
    float b = float(abs(msNoise(ivec2(i) + ivec2(1, 0), 0)) % 1000) / 1000.0;
    float c = float(abs(msNoise(ivec2(i) + ivec2(0, 1), 0)) % 1000) / 1000.0;
    float d = float(abs(msNoise(ivec2(i) + ivec2(1, 1), 0)) % 1000) / 1000.0;
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}
vec3 msChrome(vec4 base, float warm, float speed) {
    vec3 N = normalize(msViewNormal);
    vec3 I = normalize(msViewPos);
    vec3 R = reflect(I, N);
    float up = R.y * 0.5 + 0.5;
    vec3 sky = mix(vec3(0.50, 0.65, 1.00), vec3(1.00, 0.85, 0.55), warm);
    vec3 ground = mix(vec3(0.12, 0.12, 0.18), vec3(0.18, 0.13, 0.10), warm);
    vec3 env = mix(ground, sky, smoothstep(0.25, 0.75, up));
    float ang = atan(R.x, R.z);
    float sweep = sin(ang * 2.0 + GameTime * 6.2831 * speed);
    env += vec3(pow(max(0.0, sweep), 16.0)) * 1.3;
    float l = msLum(base);
    return env * (0.55 + 0.6 * l);
}

// =====================================================================
//  Per-effect TONE colours. Every effect id has a signature dyed_color
//  (written by /omforge effect and the OmCosmetics dye menu) that BOTH
//  selects the effect here AND doubles as the fallback tint: clients whose
//  core shaders are replaced (Iris/OptiFine shader packs) render the raw
//  dye, so they see roughly the effect's colour instead of the old
//  near-black #00000N. Old items dyed #00000N keep working through the
//  legacy branch in main().
//  KEEP IN SYNC with rendertype_item_entity_translucent_cull.fsh,
//  OmForgeCommand.EFFECT_TONES (OmForge), DefaultDyeMenu (OmCosmetics).
// =====================================================================
const ivec3 MS_TONES[23] = ivec3[23](
    ivec3(0xB4, 0x9C, 0xE8),  //  1 Magic
    ivec3(0xB0, 0xC0, 0xD4),  //  2 Chrome (cool steel)
    ivec3(0xA8, 0xE4, 0xEC),  //  3 Holo
    ivec3(0xE8, 0xC8, 0x64),  //  4 Chrome2 (warm gold)
    ivec3(0x48, 0xC8, 0xF8),  //  5 Electric
    ivec3(0xC2, 0xB6, 0xCE),  //  6 Glitch
    ivec3(0xE0, 0x8A, 0x38),  //  7 Dissolve
    ivec3(0xFF, 0xEF, 0xA8),  //  8 Pulse
    ivec3(0x7C, 0xD6, 0x22),  //  9 Toxic
    ivec3(0xEE, 0x70, 0xD2),  // 10 Vaporwave
    ivec3(0x44, 0x32, 0x60),  // 11 Shadow
    ivec3(0xF0, 0xC2, 0x4A),  // 12 Gold
    ivec3(0x9A, 0x9A, 0x9A),  // 13 Negative
    ivec3(0x30, 0x34, 0x62),  // 14 Starlight
    ivec3(0x8E, 0x4C, 0xB8),  // 15 Poison
    ivec3(0xE0, 0x34, 0x48),  // 16 Heartbeat
    ivec3(0xBC, 0xEA, 0xF4),  // 17 Crystal
    ivec3(0x2E, 0xD6, 0x90),  // 18 Sonar
    ivec3(0x76, 0x80, 0xE0),  // 19 Cyber (pixel-art dye; was id 30 pre-trim)
    ivec3(0xCD, 0xD2, 0xDC),  // 20 Mirror steel
    ivec3(0x9A, 0x3C, 0xFF),  // 21 Enhance aura violet  (OmRPG +10)
    ivec3(0xFF, 0xC8, 0x1E),  // 22 Enhance aura gold    (OmRPG +20)
    ivec3(0xFF, 0x3A, 0x2A)   // 23 Enhance aura crimson (OmRPG +30)
);

// 2x2 Bayer threshold (0, .5, .75, .25) on the atlas texel grid - pixel-art dithering.
float msBayer2(vec2 texel) {
    ivec2 p = ivec2(floor(texel)) & 1;
    return (p.y == 0) ? (p.x == 0 ? 0.00 : 0.50) : (p.x == 0 ? 0.75 : 0.25);
}

// Pixel-art dye (effect 19 Cyber): quantize luminance into `steps` bands (Bayer-
// dithered) and shade a 4-stop palette ramp - the base texture's own pixels stay
// readable, they are just re-coloured through the palette.
vec3 msPixelRamp(float l, vec2 texel, float steps, float dither, vec3 c0, vec3 c1, vec3 c2, vec3 c3) {
    float d = (msBayer2(texel) - 0.5) * dither / steps;
    float t = clamp(floor((l + d) * steps + 0.5) / steps, 0.0, 1.0) * 3.0;
    return (t < 1.0) ? mix(c0, c1, t)
         : (t < 2.0) ? mix(c1, c2, t - 1.0)
                     : mix(c2, c3, t - 2.0);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

    // --- OmForge MagicShaders: decode the effect id from the RAW dye colour.
    //     Legacy encoding (r=0, g=0, b=N) OR an exact match against the per-effect
    //     TONE colour table. Items with no such dye = effect 0 and take the
    //     glow/vanilla path below unchanged, so player heads + normal icons are untouched. ---
    vec4 mscol = rawColor * 255.0;
    int effect = 0;
    if (mscol.r < 0.5 && mscol.g < 0.5 && mscol.b > 0.5 && mscol.b < 20.5) {
        effect = int(mscol.b + 0.5);
    } else {
        ivec3 c = ivec3(mscol.rgb + vec3(0.5));
        if (c != ivec3(255)) {   // fast-path: undyed items are pure white
            for (int i = 0; i < 23; i++) {
                if (c == MS_TONES[i]) { effect = i + 1; break; }
            }
        }
    }

    if (effect > 0) {
        vec2 texSize = vec2(textureSize(Sampler0, 0));
        vec2 uv = texCoord0 * texSize;
        switch (effect) {
            case 1: { // Magic holographic shimmer
                color.a = 1.0;
                float tp = float(msHash(int(GameTime * 1000.0)) % 2);
                vec4 efCol = vec4(0.0);
                if (tp == 0.0) {
                    efCol = vec4(vec3(float(msNoise(ivec2(uv), int(GameTime * 20000.0)) % 64) / 64.0), 0.6);
                } else {
                    vec2 texOffs = uv + vec2(float(msHash(msHash(int(uv.y)) + int(GameTime * 20000.0)) % 3 - 1), 0.0) * 0.5;
                    float white = msLum(texelFetch(Sampler0, ivec2(texOffs), 0));
                    float cyan = msLum(texelFetch(Sampler0, ivec2(texOffs + vec2(0.5, 0.0)), 0));
                    float red = msLum(texelFetch(Sampler0, ivec2(texOffs - vec2(0.5, 0.0)), 0));
                    efCol = min(vec4(vec3(red, cyan, cyan) + white / 2.0, 0.5), vec4(1.0));
                }
                color = mix(color, efCol, efCol.a);
                color.a = 1.0;
            } break;
            case 2: { color.rgb = msChrome(color, 0.0, 0.5); } break; // Chrome cool
            case 3: { // Holographic RGB shear
                vec2 texOffs = uv + vec2(float(msHash(msHash(int(uv.y)) + int(GameTime * 15000.0)) % 3 - 1), 0.0) * 0.5;
                float white = msLum(texelFetch(Sampler0, ivec2(texOffs), 0));
                float cyan = msLum(texelFetch(Sampler0, ivec2(texOffs + vec2(0.5, 0.0)), 0));
                float red = msLum(texelFetch(Sampler0, ivec2(texOffs - vec2(0.5, 0.0)), 0));
                vec4 efCol = min(vec4(vec3(red, cyan, cyan) + white / 2.0, 0.5), vec4(1.0));
                color = mix(color, efCol, efCol.a);
                color.a = 0.75;
            } break;
            case 4: { color.rgb = msChrome(color, 1.0, 0.85); } break; // Chrome warm gold
            case 5: { // Electric arcs
                float a = abs(sin(uv.x * 0.5 + GameTime * 9000.0) + msVnoise(uv * 0.3 + GameTime * 12000.0) * 3.0 - uv.y * 0.4);
                float arc = smoothstep(0.25, 0.0, a);
                color.rgb = mix(vec3(0.0, 0.05, 0.2), vec3(0.4, 0.8, 1.0), msLum(color)) + vec3(0.6, 0.9, 1.0) * arc;
            } break;
            case 6: { // Datamosh glitch
                float t = GameTime * 10000.0;
                float band = step(0.7, msVnoise(vec2(floor(uv.y / 3.0), floor(t))));
                float sh = band * float(msHash(int(uv.y) + int(t)) % 7 - 3) * 0.004 + 0.003;
                float r = texture(Sampler0, texCoord0 + vec2(sh, 0.0)).r;
                float g = texture(Sampler0, texCoord0).g;
                float b = texture(Sampler0, texCoord0 - vec2(sh, 0.0)).b;
                color.rgb = vec3(r, g, b) + band * 0.1;
            } break;
            case 7: { // Dissolve with glowing edge
                float n = msVnoise(uv * 0.7);
                float th = 0.5 + 0.5 * sin(GameTime * 3000.0);
                if (n < th - 0.08) discard;
                color.rgb = mix(color.rgb, vec3(1.5, 0.8, 0.2), smoothstep(th, th - 0.12, n));
            } break;
            case 8: { float pulse = 0.5 + 0.5 * sin(GameTime * 4000.0); color.rgb = color.rgb * (0.6 + 1.8 * pulse); } break; // Pulse glow
            case 9: { // Toxic / acid
                float n = msVnoise(uv * 0.6 + vec2(GameTime * 3000.0, GameTime * -2000.0));
                color.rgb = mix(vec3(0.1, 0.3, 0.05), vec3(0.5, 1.0, 0.1), n) * (0.5 + msLum(color)) + vec3(0.6, 1.0, 0.2) * smoothstep(0.6, 0.9, n);
            } break;
            case 10: { // Vaporwave
                float l = msLum(color);
                float grid = max(step(0.9, fract(uv.x * 0.25 - GameTime * 2000.0)), step(0.9, fract(uv.y * 0.25)));
                color.rgb = mix(vec3(1.0, 0.3, 0.8), vec3(0.3, 0.9, 1.0), l) + vec3(0.3) * grid;
            } break;
            case 11: { // Shadow aura
                float n = msVnoise(uv * 0.5 + vec2(0.0, GameTime * 6000.0));
                color.rgb = color.rgb * 0.25 + vec3(0.25, 0.0, 0.4) * smoothstep(0.55, 0.9, n);
            } break;
            case 12: { // Gold shimmer
                float glint = pow(max(0.0, sin(uv.x * 0.4 + uv.y * 0.2 + GameTime * 7000.0)), 8.0);
                color.rgb = vec3(1.0, 0.78, 0.25) * (0.4 + msLum(color)) + vec3(1.0, 0.95, 0.7) * glint;
            } break;
            case 13: { color.rgb = mix(color.rgb, vec3(1.0) - color.rgb, 0.5 + 0.5 * sin(GameTime * 3000.0)); } break; // Negative pulse
            case 14: { // Starlight / glitter
                float t = GameTime * 5000.0;
                float star = step(0.97, msVnoise(uv * 1.2 + floor(t)));
                float tw = 0.5 + 0.5 * sin(t * 3.0 + uv.x + uv.y);
                color.rgb = color.rgb * 0.5 + vec3(star * tw) * vec3(1.0, 1.0, 0.9) + vec3(0.02, 0.02, 0.06);
            } break;
            case 15: { // Poison smoke
                float n = msVnoise(uv * 0.4 + vec2(sin(uv.y * 0.1) * GameTime * 1500.0, GameTime * 4000.0));
                color.rgb = mix(vec3(0.05, 0.1, 0.02), vec3(0.4, 0.95, 0.2), smoothstep(0.3, 0.8, n));
                color.rgb = mix(color.rgb, vec3(0.5, 0.1, 0.6), 0.3 * smoothstep(0.55, 0.9, n));
            } break;
            case 16: { // Heartbeat
                float p = mod(GameTime * 1500.0, 1.0);
                float b = exp(-p * 10.0) + 0.6 * exp(-mod(p + 0.82, 1.0) * 10.0);
                color.rgb = mix(color.rgb * 0.4, vec3(1.0, 0.1, 0.1) + color.rgb, clamp(b, 0.0, 1.0));
            } break;
            case 17: { // Crystal prismatic
                vec3 N = normalize(msViewNormal); vec3 I = normalize(msViewPos);
                vec3 R = refract(I, N, 0.75);
                float h = fract(R.x * 0.5 + R.y * 0.5 + GameTime * 1000.0);
                color.rgb = mix(color.rgb, msHue(h), 0.6) + vec3(pow(max(0.0, R.y), 4.0)) * 0.5;
            } break;
            case 18: { // Sonar rings
                float d = length(fract(uv * 0.04) - 0.5);
                float ring = smoothstep(0.08, 0.0, abs(fract(d * 3.0 - GameTime * 2000.0) - 0.5));
                color.rgb = mix(vec3(0.0, 0.1, 0.05), vec3(0.1, 1.0, 0.3), msLum(color)) + vec3(0.0, 1.0, 0.4) * ring;
            } break;
            // ---- 19..20: kept pixel-art dye (Cyber) + the new mirror-steel effect ----
            case 19: {
                // Cyber - neon magenta->cyan pixel ramp with a rolling scanline (emissive)
                vec3 px = msPixelRamp(msLum(color), uv, 5.0, 0.5,
                    vec3(0.047, 0.016, 0.188), vec3(0.784, 0.118, 0.824),
                    vec3(0.141, 0.878, 0.941), vec3(0.918, 0.980, 1.000));
                float scan = 0.82 + 0.18 * step(0.5, fract(uv.y * 0.5 - GameTime * 1200.0));
                color.rgb = px * scan;
            } break;
            case 20: {
                // Mirror steel - polished metal: studio reflection, horizon flash,
                // sliding light strips, fresnel edge gleam + a fast travelling glint
                vec3 N = normalize(msViewNormal);
                vec3 I = normalize(msViewPos);
                vec3 R = reflect(I, N);
                float up = R.y * 0.5 + 0.5;
                vec3 env = mix(vec3(0.10, 0.11, 0.13), vec3(0.62, 0.68, 0.78), smoothstep(0.18, 0.52, up));
                env = mix(env, vec3(1.20, 1.25, 1.35), pow(1.0 - abs(up - 0.5) * 2.0, 6.0));
                float ang = atan(R.x, R.z);
                float strips = pow(max(0.0, sin(ang * 3.0 + GameTime * 500.0)), 24.0)
                             + 0.6 * pow(max(0.0, sin(ang * 7.0 - GameTime * 800.0 + 1.7)), 48.0);
                env += vec3(1.0, 1.0, 1.05) * strips;
                float fres = pow(1.0 - max(0.0, dot(-I, N)), 3.0);
                env += vec3(0.35, 0.38, 0.45) * fres;
                float glint = pow(max(0.0, sin((uv.x + uv.y) * 0.3 + GameTime * 6000.0)), 32.0);
                env += vec3(glint) * 0.8;
                color.rgb = env * (0.45 + 0.75 * msLum(color));
            } break;
            // ---- 21..23 Enhance aura v4 (OmRPG +10 / +20 / +30, Blade 2026-09-14: v3 was too loud ->
            //      subtle). The art is lightly recoloured toward the tier hue keeping its own light/dark
            //      (gold pushed a bit more because the base textures are already brown/gold), a soft
            //      breathing emissive lift, one thin enchant-style sheen along the blade, faint rim.
            //      No sparks / noise. Emissive (no light) so it still reads at night.
            case 21: case 22: case 23: {
                vec3 tint = (effect == 21) ? vec3(0.60, 0.20, 1.00)
                          : (effect == 22) ? vec3(1.00, 0.78, 0.00)
                          :                  vec3(1.00, 0.14, 0.10);
                vec3 hot  = (effect == 21) ? vec3(0.92, 0.78, 1.00)
                          : (effect == 22) ? vec3(1.00, 1.00, 0.80)
                          :                  vec3(1.00, 0.72, 0.55);
                float mixAmt  = (effect == 22) ? 0.50 : 0.38;
                float glowAmt = (effect == 22) ? 0.16 : 0.12;
                float sheenAmt = (effect == 22) ? 0.45 : 0.35;
                float l = msLum(color);
                float t = GameTime * 1000.0;
                float breathe = 0.5 + 0.5 * sin(t * 1.5);
                vec3 art = mix(color.rgb, tint * (0.22 + 1.15 * l), mixAmt);
                vec3 glow = tint * (glowAmt * (0.55 + 0.45 * breathe)) * (0.35 + 0.65 * l);
                float d = (uv.x + uv.y) * 0.09;
                float sheen = pow(max(0.0, sin(d - t * 2.4)), 20.0);
                vec3 N = normalize(msViewNormal);
                vec3 I = normalize(msViewPos);
                float rim = pow(1.0 - max(0.0, dot(-I, N)), 3.0);
                color.rgb = art + glow + hot * sheen * sheenAmt * (0.5 + 0.5 * l) + tint * rim * 0.18;
            } break;
            default: { color *= vertexColor; } break;
        }
        fragColor = apply_fog(color * ColorModulator, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
        return;
    }

    // SMP build: no effect==0 emissive glow here (non-dyed items stay exactly vanilla 26.2).


    // --- vanilla 26.2 item path (normal items, player heads, GUI icons) ---
    color *= vertexColor * ColorModulator;
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
