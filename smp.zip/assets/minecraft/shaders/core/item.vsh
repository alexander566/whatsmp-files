#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;
out vec2 texCoord0;
out float vIsGui;
// --- OmForge MagicShaders item effects (/omf effect) ---
flat out vec4 rawColor;   // raw dye colour (pre-lighting) -> effect id decode
out vec3 msViewNormal;    // view-space normal  (chrome cases)
out vec3 msViewPos;       // view-space position (view direction)

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
    // 1.0 in a GUI (orthographic projection: ProjMat[3].x == -1), 0.0 in the world.
    vIsGui = (ProjMat[3].x < -0.5) ? 1.0 : 0.0;

    // --- OmForge MagicShaders item effects ---
    rawColor = Color;
    msViewNormal = mat3(ModelViewMat) * Normal;
    msViewPos = (ModelViewMat * vec4(Position, 1.0)).xyz;
}
